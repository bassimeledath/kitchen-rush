#!/usr/bin/env python3
"""Independent gate audit against exact manifests, request accounting and fresh replay."""
from __future__ import annotations

import argparse
import json
import math
import sys
from collections import Counter
from pathlib import Path

ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'src'))
from kitchenrush.v2.analysis import summarize  # noqa: E402
from kitchenrush.v2.environment import (Engine, candidates, decision, deserialize_spec, digest,  # noqa: E402
                                       public_state, protocol_hash, verify_replay)
from kitchenrush.v2.evaluation import write_json  # noqa: E402
from kitchenrush.v2.ledger import Ledger  # noqa: E402
from kitchenrush.v2.providers import Client, Model  # noqa: E402
from kitchenrush.tools import ToolCall  # noqa: E402


def audit(stage):
    manifest=json.loads((ROOT/f'data/v2/{stage}-manifest.json').read_text())
    assert manifest['protocol_hash']==protocol_hash(), 'stale manifest'
    ledger=Ledger(ROOT/'runs/v2/spend.sqlite')
    episodes=[]
    usage_requests=set()
    for job in manifest['jobs']:
        ep=json.loads((ROOT/'runs/v2'/stage/(job['id']+'.json')).read_text())
        assert ep['status']=='complete', (ep['id'],ep['status'])
        assert ep['protocol_hash']==manifest['protocol_hash']
        assert ep['model']==manifest['models'][job['model']]
        assert ep['dollar_cap']==job['dollar_cap'] and ep['token_cap']==job['token_cap']
        assert ep['spec']['seed']==job['seed'] and digest(ep['spec'])==ep['spec_hash']
        assert ep['reason']!='spending_gate', 'stage/global spend prevented completion'
        assert ep['cost_usd'] <= ep['dollar_cap']+1e-9
        assert len(ep['actions']) == len(ep['requests']), 'unexecuted request in scored episode'
        assert math.isclose(sum(r['cost_usd'] for r in ep['requests']),ledger.used(ep['id']),abs_tol=2e-7)
        assert ep['input_tokens']==sum(r['input_tokens'] for r in ep['requests'])
        assert ep['output_tokens']==sum(r['output_tokens'] for r in ep['requests'])
        if ep['token_cap'] is not None: assert ep['output_tokens']<=ep['token_cap']
        engine=Engine(deserialize_spec(ep['spec']))
        client=Client(Model(**ep['model']))
        for index,(record,action) in enumerate(zip(ep['requests'],ep['actions'],strict=True)):
            assert record['id'] not in usage_requests
            usage_requests.add(record['id'])
            state=public_state(engine)
            # Budget is the only variable state item outside the replayed public kitchen.
            resource=record['canonical']['state']['resource']
            expected,options=decision(state,resource)
            assert expected==record['canonical'], 'hidden or altered model information'
            if ep['model']['provider']=='TypeSafe':
                assert record['payload']=={'model':ep['model']['model'],**expected}
            else:
                assert json.loads(record['payload']['messages'][1]['content'])==expected
            ni,no,cost=client.usage(record['response'],record['payload'])
            assert (ni,no)==(record['input_tokens'],record['output_tokens'])
            assert math.isclose(cost,record['cost_usd'],abs_tol=1e-12)
            client.validate_identity(record['response'])
            choice=client.select(record['response'])
            selected=options.get(choice) if isinstance(choice,str) else None
            assert action==({'name':selected.name,'arguments':selected.arguments} if selected
                            else {'name':'invalid_model_selection','arguments':{}})
            engine.step([ToolCall(**action)])
            assert record['post_state_hash']==digest(public_state(engine))
        verify_replay(ep)
        episodes.append(ep)
    # Each model in the main economic pilot must have the same task/budget/trial grid.
    grids={}
    for model in manifest['models']:
        grids[model]=Counter((e['spec']['seed'],e['dollar_cap']) for e in episodes
                             if e['model']['key']==model and e['token_cap'] is None)
    assert all(g==next(iter(grids.values())) for g in grids.values())
    snapshot=ledger.snapshot()
    assert snapshot['unresolved_requests']==0 and snapshot['overruns']==0
    result={'status':'passed','stage':stage,'episodes':len(episodes),'requests_verified':len(usage_requests),
            'protocol_hash':protocol_hash(),'ledger':snapshot,'summary':summarize(episodes)}
    write_json(ROOT/f'data/v2/{stage}-gate.json',result)
    print(json.dumps(result,indent=2))
    return result

if __name__=='__main__':
    p=argparse.ArgumentParser(); p.add_argument('stage',choices=['canary','smoke','pilot'])
    audit(p.parse_args().stage)
