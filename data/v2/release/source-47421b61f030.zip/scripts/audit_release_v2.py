#!/usr/bin/env python3
"""Independent, read-only verification of a complete v2 release batch before gating it."""

from __future__ import annotations

import argparse
import hashlib
import importlib.util
import json
import math
import sqlite3
import sys
import zipfile
from collections import Counter, defaultdict
from dataclasses import asdict
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))
from kitchenrush.tools import ToolCall  # noqa: E402
from kitchenrush.v2.analysis import summarize  # noqa: E402
from kitchenrush.v2.environment import (  # noqa: E402
    MAX_DECISIONS,
    PROTOCOL,
    Engine,
    decision,
    digest,
    generate,
    protocol_hash,
    public_state,
    quality,
    scripted_episode,
    serialize_spec,
)
from kitchenrush.v2.ledger import STAGES  # noqa: E402
from kitchenrush.v2.providers import Client, Model  # noqa: E402

SCALE = 1_000_000_000


def require(condition, message):
    if not condition:
        raise ValueError(message)


def money(value):
    require(
        type(value) in (int, float) and math.isfinite(value) and value >= 0,
        "invalid monetary value",
    )
    return math.ceil(value * SCALE - 1e-9)


def read_json(path):
    return json.loads(path.read_text())


def normalized_payload(payload):
    result = json.loads(json.dumps(payload))
    if "messages" in result:
        result["messages"][1]["content"] = json.loads(result["messages"][1]["content"])
    return result


def response_usage(response, model):
    usage = response["usage"]
    jev = model.provider == "TypeSafe"
    ni = usage["input_tokens" if jev else "prompt_tokens"]
    no = usage["output_tokens" if jev else "completion_tokens"]
    require(all(type(n) is int and n >= 0 for n in (ni, no)), "invalid response token counts")
    cost = ni * model.input_price if jev else float(usage["cost"])
    money(cost)
    require(response.get("model") == model.model, "response model identity mismatch")
    if not jev:
        require(
            response.get("provider", "").casefold() == model.provider.casefold(),
            "response provider identity mismatch",
        )
    return ni, no, cost


def response_selection(response, model):
    # Independently decode native replies, including invalid/refused/truncated generations.
    try:
        if model.provider == "TypeSafe":
            answer = response["answers"]["next_action"]
            return answer["choice"] if answer["type"] == "choice" else None
        choice = response["choices"][0]
        if choice["finish_reason"] != "stop":
            return None
        answer = json.loads(choice["message"]["content"])
        return answer["action"] if isinstance(answer, dict) and set(answer) == {"action"} else None
    except (KeyError, TypeError, ValueError, IndexError):
        return None


def ledger_snapshot(path, opening):
    require(path.is_file(), "missing release ledger")
    with sqlite3.connect(path.resolve().as_uri() + "?mode=ro", uri=True) as con:
        con.execute("BEGIN")
        require(
            con.execute("SELECT cap FROM meta WHERE id=1").fetchone() == (200 * SCALE,),
            "release ledger does not have immutable $200 ceiling",
        )
        require(
            con.execute("SELECT amount FROM opening WHERE id=1").fetchone() == (money(opening),),
            "opening balance mismatch",
        )
        rows = con.execute(
            "SELECT id,episode,stage,reserved,actual,status FROM requests"
        ).fetchall()
    require(
        all(r[5] in ("settled", "retained_failure") for r in rows),
        "ledger has unresolved requests, overrun, or unknown status",
    )
    require(
        all(
            (r[5] == "settled" and type(r[4]) is int and 0 <= r[4] <= r[3])
            or (r[5] == "retained_failure" and r[4] is None)
            for r in rows
        ),
        "invalid settled/retained ledger row",
    )
    stage_totals = Counter()
    for row in rows:
        require(row[2] in STAGES, "unknown ledger stage")
        stage_totals[row[2]] += row[4] if row[4] is not None else row[3]
    require(
        all(total <= money(STAGES[stage]) for stage, total in stage_totals.items()),
        "stage spending exceeds its ceiling",
    )
    accounted = money(opening) + sum(r[4] if r[4] is not None else r[3] for r in rows)
    require(accounted <= 200 * SCALE, "global spending exceeds $200")
    return {r[0]: r[1:] for r in rows}, {
        "cap_usd": 200.0,
        "prior_accounted_usd": opening,
        "accounted_usd": accounted / SCALE,
        "settled_usd": sum(r[4] or 0 for r in rows) / SCALE,
        "retained_liability_usd": sum(r[3] for r in rows if r[4] is None) / SCALE,
        "requests": len(rows),
        "unresolved_requests": 0,
        "overruns": 0,
    }


def verify_archive(root, manifest):
    require(manifest["protocol_hash"] == protocol_hash(), "current protocol differs from batch")
    archive = root / f"data/v2/release/source-{manifest['protocol_hash'][:12]}.zip"
    with zipfile.ZipFile(archive) as z:
        names = z.namelist()
        require(len(names) == len(set(names)), "duplicate archive members")
        package = {p.relative_to(root).as_posix() for p in (root / "src").rglob("*.py")}
        require(
            package == {n for n in names if n.startswith("src/") and n.endswith(".py")},
            "archive source package membership differs",
        )
        require("scripts/release_v2.py" in names, "archive omits release runner")
        require(
            all(
                n.endswith(".py")
                and n.startswith(("src/", "scripts/"))
                and ".." not in Path(n).parts
                for n in names
            ),
            "unexpected archive contents",
        )
        for name in names:
            require(
                (root / name).is_file() and (root / name).read_bytes() == z.read(name),
                f"archived source differs: {name}",
            )
    return hashlib.sha256(archive.read_bytes()).hexdigest()


def verify_campaign(root, manifest):
    roster_path = root / "data/v2/release-roster.json"
    roster = read_json(roster_path)
    original = read_json(root / "data/v2/roster.json")
    historical = Counter(row["label"] for row in original["models"])
    retained = Counter(label for row in roster["models"] for label in row["historical_labels"])
    require(retained == historical, "release roster drops or duplicates historical labels")
    rows = roster["models"]
    require(
        len({r["key"] for r in rows}) == len(rows) == roster["configuration_count"],
        "release roster configuration count/key mismatch",
    )
    require(len(rows) == original["canonical_entry_count"], "canonical roster coverage changed")
    require(
        sum(retained.values()) == roster["historical_label_count"],
        "historical roster count mismatch",
    )
    blocked = []
    for row in rows:
        if row["status"].startswith("blocked"):
            require(bool(row.get("block_reason")), "blocked model has no explicit reason")
            blocked.append({"key": row["key"], "reason": row["block_reason"]})
        else:
            require(
                row["status"]
                in ("pending_canary", "passed_canary", "pending_corrected_protocol_canary"),
                "unrecognized release roster eligibility status",
            )
    require(
        hashlib.sha256(roster_path.read_bytes()).hexdigest() == manifest["roster_sha256"],
        "manifest does not bind current frozen roster",
    )
    module_spec = importlib.util.spec_from_file_location(
        "release_audit_expected_plan", root / "scripts/release_v2.py"
    )
    runner = importlib.util.module_from_spec(module_spec)
    module_spec.loader.exec_module(runner)
    runner.ROOT = root
    expected = runner.plan(manifest["batch"])
    require(manifest == expected, "manifest differs from complete frozen batch plan")
    campaign = {
        key: manifest[key]
        for key in ("protocol_hash", "configuration_hash", "roster_sha256", "opening_balance")
    }
    require(
        read_json(root / "data/v2/release/campaign.json") == campaign,
        "batch differs from immutable campaign configuration",
    )
    return {
        "total_configurations": len(rows),
        "eligible_configurations": len(rows) - len(blocked),
        "blocked_configurations": blocked,
        "historical_labels": sum(retained.values()),
    }


def verify_grid(manifest):
    jobs = manifest["jobs"]
    require(jobs and manifest["models"], "empty manifest")
    require(len({j["id"] for j in jobs}) == len(jobs), "duplicate episode ids")
    require(
        {j["model"] for j in jobs} == set(manifest["models"]),
        "manifest models and evaluated models differ",
    )
    semantic = set()
    by_view = defaultdict(lambda: defaultdict(Counter))
    by_budget = defaultdict(lambda: defaultdict(Counter))
    for job in jobs:
        require(type(job["trial"]) is int and job["trial"] >= 0, "invalid trial")
        require(type(job["seed"]) is int and job["size"] in (2, 3, 4), "invalid seed/family")
        money(job["dollar_cap"])
        require(
            job["token_cap"] is None or (type(job["token_cap"]) is int and job["token_cap"] > 0),
            "invalid token cap",
        )
        require(Path(job["id"]).name == job["id"], "episode id is not a filename")
        view = "USD" if job["token_cap"] is None else "tokens"
        task = (job["split"], job["size"], job["seed"], job["trial"])
        budget = (job["dollar_cap"], job["token_cap"])
        key = (job["model"], *task, *budget)
        require(key not in semantic, "duplicate semantic experiment")
        semantic.add(key)
        by_view[view][job["model"]][(*task, *budget)] += 1
        by_budget[(view, job["model"])][budget][task] += 1
        if view == "tokens":
            require(
                manifest["models"][job["model"]]["provider"] != "TypeSafe",
                "Jev cannot enter generation-token track",
            )
    for view, models in by_view.items():
        grids = list(models.values())
        require(all(g == grids[0] for g in grids), f"unmatched model grid in {view}")
    for key, budgets in by_budget.items():
        grids = list(budgets.values())
        require(all(g == grids[0] for g in grids), f"different kitchens across budgets: {key}")


def audit(batch, *, root=ROOT, write_gate=True):
    require(Path(batch).name == batch and batch not in (".", ".."), "invalid batch name")
    if write_gate:
        # A failed re-audit must not leave an earlier successful gate looking current.
        (root / f"data/v2/release/{batch}-gate.json").unlink(missing_ok=True)
    manifest_path = root / f"data/v2/release/{batch}-manifest.json"
    manifest = read_json(manifest_path)
    require(manifest["batch"] == batch, "batch label mismatch")
    verify_grid(manifest)
    coverage = verify_campaign(root, manifest)
    archive_hash = verify_archive(root, manifest)
    opening = manifest["opening_balance"]
    # Independently establish the brought-forward amount from the original ledger.
    old = root / "runs/v2/spend.sqlite"
    require(old.is_file(), "missing prior spending ledger")
    with sqlite3.connect(old.resolve().as_uri() + "?mode=ro", uri=True) as con:
        prior = con.execute(
            "SELECT COALESCE(SUM(COALESCE(actual,reserved)),0) FROM requests"
        ).fetchone()[0]
        tables = {r[0] for r in con.execute("SELECT name FROM sqlite_master WHERE type='table'")}
        if "opening" in tables:
            prior += con.execute("SELECT amount FROM opening WHERE id=1").fetchone()[0]
    require(prior == money(opening), "opening balance does not reconcile to original ledger")
    ledger, snapshot = ledger_snapshot(root / "runs/v2/release/spend.sqlite", opening)
    folder = root / f"runs/v2/release/{batch}"
    expected_ids = {j["id"] for j in manifest["jobs"]}
    require(
        {p.stem for p in folder.glob("*.json")} == expected_ids,
        "missing or unexpected episode artifacts",
    )
    episodes, used_requests = [], set()
    batch_units = boundary_units = 0
    for job in manifest["jobs"]:
        ep = read_json(folder / (job["id"] + ".json"))
        label = job["id"]
        require(ep["id"] == label and ep["status"] == "complete", f"incomplete episode {label}")
        require(
            ep["protocol"] == PROTOCOL and ep["protocol_hash"] == manifest["protocol_hash"],
            f"protocol mismatch {label}",
        )
        require(ep["stage"] == manifest["stage"], f"stage mismatch {label}")
        require(
            ep["accounting_contract"] == "actual-cost-action-admission-1",
            "wrong accounting contract",
        )
        model = Model(**manifest["models"][job["model"]])
        require(ep["model"] == asdict(model) and model.key == job["model"], "model config mismatch")
        require(
            ep["dollar_cap"] == job["dollar_cap"] and ep["token_cap"] == job["token_cap"],
            "resource allowance mismatch",
        )
        spec = generate(job["seed"], job["split"], job["size"])
        require(
            ep["spec"] == serialize_spec(spec) and ep["spec_hash"] == digest(ep["spec"]),
            "instance generation/hash mismatch",
        )
        witness = scripted_episode(spec)
        require(
            witness["quality"] == 100
            and witness["invalid"] == 0
            and ep["feasibility_witness_hash"] == digest(witness["actions"]),
            "feasibility witness mismatch",
        )
        engine, client = Engine(spec, record_trace=True), Client(model)
        spent = ni_total = no_total = admitted = accepted = boundary = 0
        for index, record in enumerate(ep["requests"]):
            require(not engine.terminated and admitted < MAX_DECISIONS, "request after game end")
            require(spent < money(ep["dollar_cap"]), "request after dollar allowance exhausted")
            remaining_tokens = None if ep["token_cap"] is None else ep["token_cap"] - no_total
            require(
                remaining_tokens is None or remaining_tokens > 0, "request after token exhaustion"
            )
            remaining_usd = max(0, ep["dollar_cap"] - spent / SCALE)
            resource = {
                "kind": "USD" if remaining_tokens is None else "generation_tokens",
                "allowance": ep["dollar_cap"] if remaining_tokens is None else ep["token_cap"],
                "remaining": remaining_usd if remaining_tokens is None else remaining_tokens,
                "decisions_remaining": MAX_DECISIONS - admitted,
            }
            canonical, options = decision(public_state(engine), resource)
            require(record["canonical"] == canonical, "altered/hidden information in request")
            maximum = (
                model.max_output
                if remaining_tokens is None
                else min(model.max_output, remaining_tokens)
            )
            payload = client.payload(canonical, maximum)
            require(
                normalized_payload(record["payload"]) == normalized_payload(payload),
                "altered provider payload/assistance",
            )
            require(
                model.prompt_limit is not None and model.prompt_limit > 0, "missing operational cap"
            )
            reserve = (
                model.prompt_limit * (model.reservation_input_price or model.input_price)
                + (0 if model.provider == "TypeSafe" else maximum * model.output_price)
                + model.request_fee
            )
            require(
                record["reserved_usd"] == reserve
                and record["reservation_basis"] == model.reservation_basis,
                "reservation mismatch",
            )
            rid = f"{label}:{index}"
            require(
                record["id"] == rid and rid not in used_requests, "request identity reused/altered"
            )
            used_requests.add(rid)
            ni, no, cost = response_usage(record["response"], model)
            require(
                ni <= model.prompt_limit and (model.provider == "TypeSafe" or no <= maximum),
                "provider token bound exceeded",
            )
            require(
                (ni, no) == (record["input_tokens"], record["output_tokens"])
                and cost == record["cost_usd"],
                "usage-derived accounting mismatch",
            )
            require(
                ledger.get(rid)
                == (label, manifest["stage"], money(reserve), money(cost), "settled"),
                "request does not reconcile to settled ledger row",
            )
            ni_total += ni
            no_total += no
            spent += money(cost)
            if spent > money(ep["dollar_cap"]):
                require(
                    index == len(ep["requests"]) - 1 and record["admitted"] is False,
                    "boundary request was admitted or followed by another request",
                )
                require(
                    not any(k in record for k in ("selection", "post_quality", "post_state_hash")),
                    "boundary response interpreted as an action",
                )
                boundary = money(cost)
                continue
            require(record["admitted"] is True, "affordable action not admitted")
            selection = response_selection(record["response"], model)
            require(record["selection"] == selection, "stored selection differs from response")
            selected = options.get(selection) if isinstance(selection, str) else None
            call = selected or ToolCall("invalid_model_selection", {})
            require(
                admitted < len(ep["actions"]) and ep["actions"][admitted] == asdict(call),
                "executed action differs from selected candidate",
            )
            engine.step([call])
            admitted += 1
            accepted = spent
            require(
                sum(f["kind"] == "action" for f in engine.trace) == admitted,
                "selection/action-frame count mismatch",
            )
            require(
                record["post_state_hash"] == digest(public_state(engine))
                and record["post_quality"] == quality(engine),
                "post-action state/quality mismatch",
            )
        require(admitted == len(ep["actions"]), "unaccounted actions")
        require(
            ep["input_tokens"] == ni_total and ep["output_tokens"] == no_total,
            "token total mismatch",
        )
        require(
            ep["token_cap"] is None or no_total <= ep["token_cap"],
            "episode generation cap exceeded",
        )
        require(
            ep["cost_usd"] == spent / SCALE
            and ep["accepted_cost_usd"] == accepted / SCALE
            and ep["boundary_cost_usd"] == boundary / SCALE,
            "episode cost totals mismatch",
        )
        require(accepted <= money(ep["dollar_cap"]), "accepted action cost exceeds allowance")
        if boundary:
            reason = "dollar_budget_exhausted"
        elif engine.terminated:
            reason = "game_terminal"
        elif admitted == MAX_DECISIONS:
            reason = "decision_limit"
        elif ep["token_cap"] is not None and no_total == ep["token_cap"]:
            reason = "token_budget_exhausted"
        elif spent == money(ep["dollar_cap"]):
            reason = "dollar_budget_exhausted"
        else:
            raise ValueError(f"unjustified stopping in {label}")
        require(ep["reason"] == reason, "incorrect termination reason")
        require(
            ep["completed"] == engine.counters["orders_served"]
            and ep["invalid"] == engine.counters["invalid_actions"]
            and ep["invalid_by_reason"] == engine.counters["invalid_by_reason"]
            and ep["quality"] == quality(engine),
            "final score/counter mismatch",
        )
        require(digest(ep["frames"]) == digest(engine.trace), "fresh frame replay mismatch")
        # Set this only after independent reconstruction; never trust the saved flag.
        ep["replay_verified"] = True
        episodes.append(ep)
        batch_units += spent
        boundary_units += boundary
    require(
        {rid for rid, row in ledger.items() if row[0] in expected_ids} == used_requests,
        "missing or unaccounted paid request for batch episodes",
    )
    result = {
        "status": "passed",
        "batch": batch,
        "stage": manifest["stage"],
        "episodes": len(episodes),
        "requests_verified": len(used_requests),
        "protocol_hash": manifest["protocol_hash"],
        "source_archive_sha256": archive_hash,
        "manifest_sha256": hashlib.sha256(manifest_path.read_bytes()).hexdigest(),
        "configuration_hash": manifest["configuration_hash"],
        "roster_sha256": manifest["roster_sha256"],
        "roster_coverage": coverage,
        "batch_cost_usd": batch_units / SCALE,
        "boundary_cost_usd": boundary_units / SCALE,
        "ledger": snapshot,
        "summary": summarize(episodes),
    }
    if write_gate:
        target = root / f"data/v2/release/{batch}-gate.json"
        temporary = target.with_suffix(".json.tmp")
        temporary.write_text(json.dumps(result, indent=2, sort_keys=True) + "\n")
        temporary.replace(target)
    return result


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--batch", required=True)
    args = parser.parse_args()
    result = audit(args.batch)
    print(json.dumps({k: v for k, v in result.items() if k != "summary"}, indent=2))
