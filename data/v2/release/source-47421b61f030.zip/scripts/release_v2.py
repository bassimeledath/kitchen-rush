#!/usr/bin/env python3
"""Staged v2 release runner. No batch advances without its independently audited gate."""

from __future__ import annotations

import argparse
import hashlib
import json
import sqlite3
import sys
import zipfile
from concurrent.futures import ThreadPoolExecutor
from dataclasses import asdict
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))
from kitchenrush.v2.environment import (  # noqa: E402
    PROTOCOL,
    digest,
    generate,
    protocol_hash,
    scripted_episode,
    verify_replay,
)
from kitchenrush.v2.evaluation import run_episode, write_json  # noqa: E402
from kitchenrush.v2.ledger import SCALE, Ledger  # noqa: E402
from kitchenrush.v2.providers import Client, Model, load_env  # noqa: E402

DATA = ROOT / "data/v2/release"
RUNS = ROOT / "runs/v2/release"
CONTROLS = ("jev", "gpt-5-4-mini-think", "claude-sonnet-4-6")


def prior_accounting():
    path = ROOT / "runs/v2/spend.sqlite"
    with sqlite3.connect(f"file:{path}?mode=ro", uri=True) as con:
        if con.execute(
            "SELECT 1 FROM requests WHERE status IN ('reserved','uncertain','overrun')"
        ).fetchone():
            raise ValueError("prior accounting is unresolved")
        amount = con.execute("SELECT SUM(COALESCE(actual,reserved)) FROM requests").fetchone()[0]
    return amount / SCALE


def models():
    roster = json.loads((ROOT / "data/v2/release-roster.json").read_text())
    result = {}
    for row in roster["models"]:
        if row["status"].startswith("blocked"):
            continue
        jev = row["provider"] == "TypeSafe"
        result[row["key"]] = Model(
            key=row["key"],
            model=row["model"],
            provider=row["provider"],
            input_price=row["input_price"],
            output_price=row["output_price"],
            reasoning=row["reasoning"],
            max_output=row["max_output"],
            route_slug=row["route_slug"],
            prompt_limit=1_000_000 if jev else row["context_length"],
            reservation_input_price=row.get("operational_max_input_price", row["input_price"]),
            request_fee=row["request_fee"],
            reservation_basis=(
                "estimated_1M_input_tokens_no_documented_provider_limit"
                if jev
                else "frozen_endpoint_context_and_max_input_tariff"
            ),
        )
    return result


def plan(batch):
    catalog = models()
    jobs = []

    def add(key, seed, size, dollars, tokens=None, split="development", trial=0):
        jobs.append(
            dict(
                id=f"{batch}-{key}-{seed}-{size}-{trial}-d{dollars}-t{tokens}",
                model=key,
                seed=seed,
                split=split,
                size=size,
                trial=trial,
                dollar_cap=dollars,
                token_cap=tokens,
            )
        )

    if batch == "corrected_canary":
        stage, previous = "corrected_validation", "offline"
        for key in CONTROLS:
            add(key, 56000, 3, 0.15)
    elif batch == "corrected_pilot":
        stage, previous = "corrected_validation", "corrected_canary"
        for size in (2, 3, 4):
            for dollars in (0.05, 0.4):
                for key in CONTROLS:
                    add(key, 56100 + size, size, dollars, split="pilot")
        for tokens in (512, 2048, 8192):
            for key in CONTROLS[1:]:
                add(key, 56200, 3, 1.0, tokens, split="pilot")
    elif batch == "roster_canary":
        stage, previous = "roster_canary", "corrected_pilot"
        for key in catalog:
            add(key, 56300, 3, 0.4)
    elif batch in ("main_1", "main_2", "confirmation"):
        stage = "confirmation" if batch == "confirmation" else "main"
        previous = {"main_1": "roster_canary", "main_2": "main_1", "confirmation": "main_2"}[batch]
        seed_base = {"main_1": 57000, "main_2": 58000, "confirmation": 59000}[batch]
        for size in (2, 3, 4):
            for dollars in (0.4,) if stage == "confirmation" else (0.05, 0.15, 0.4):
                for key in catalog:
                    add(
                        key,
                        seed_base + size,
                        size,
                        dollars,
                        split="confirmation" if stage == "confirmation" else "main",
                    )
    else:
        raise ValueError("unknown batch")
    return dict(
        batch=batch,
        stage=stage,
        previous=previous,
        protocol=PROTOCOL,
        protocol_hash=protocol_hash(),
        configuration_hash=digest({k: asdict(v) for k, v in catalog.items()}),
        roster_sha256=hashlib.sha256(
            (ROOT / "data/v2/release-roster.json").read_bytes()
        ).hexdigest(),
        opening_balance=prior_accounting(),
        models={k: asdict(catalog[k]) for k in sorted({j["model"] for j in jobs})},
        jobs=jobs,
        max_decisions=160,
        cost_policy="Actual paid cost includes the first non-admitted boundary response. "
        "Operational reservations constrain stage/global spending, not scored admission. "
        "TypeSafe reservation is an explicit estimate, not a guaranteed provider maximum.",
    )


def archive_source():
    archive = DATA / f"source-{protocol_hash()[:12]}.zip"
    files = sorted((ROOT / "src").rglob("*.py"))
    files += [ROOT / "scripts/release_v2.py", ROOT / "scripts/audit_release_v2.py"]
    if archive.exists():
        with zipfile.ZipFile(archive) as bundle:
            if any(bundle.read(str(p.relative_to(ROOT))) != p.read_bytes() for p in files):
                raise ValueError("source archive differs: preserve generation and audit")
        return
    with zipfile.ZipFile(archive, "w", zipfile.ZIP_DEFLATED) as bundle:
        for path in files:
            bundle.write(path, path.relative_to(ROOT))


def offline():
    rows = []
    for split in ("development", "pilot", "main", "confirmation"):
        for size in (2, 3, 4):
            for seed in range(20):
                ep = scripted_episode(generate(seed, split, size))
                if ep["quality"] != 100 or ep["invalid"] or not verify_replay(ep):
                    raise ValueError(f"infeasible kitchen: {split}/{size}/{seed}")
                rows.append(dict(split=split, size=size, seed=seed, actions=len(ep["actions"])))
    report = dict(
        status="passed",
        protocol=PROTOCOL,
        protocol_hash=protocol_hash(),
        solved_replayed_instances=len(rows),
        instances=rows,
    )
    write_json(DATA / "offline-gate.json", report)
    print(json.dumps({k: v for k, v in report.items() if k != "instances"}), flush=True)


def paid(batch, workers):
    manifest = plan(batch)
    campaign = {
        k: manifest[k]
        for k in ("protocol_hash", "configuration_hash", "roster_sha256", "opening_balance")
    }
    campaign_path = DATA / "campaign.json"
    if campaign_path.exists():
        if json.loads(campaign_path.read_text()) != campaign:
            raise ValueError("campaign configuration changed; do not reuse prior gates")
    elif batch != "corrected_canary":
        raise ValueError("campaign must start with the corrected canary")
    gate_path = DATA / f"{manifest['previous']}-gate.json"
    if not gate_path.exists():
        raise ValueError("previous checkpoint audit missing")
    gate = json.loads(gate_path.read_text())
    if gate["status"] != "passed" or gate["protocol_hash"] != protocol_hash():
        raise ValueError("previous checkpoint did not pass for this protocol")
    if manifest["previous"] != "offline":
        previous_path = DATA / f"{manifest['previous']}-manifest.json"
        if gate.get("manifest_sha256") != hashlib.sha256(previous_path.read_bytes()).hexdigest():
            raise ValueError("predecessor manifest no longer matches its audited gate")
        previous = json.loads(previous_path.read_text())
        if previous["configuration_hash"] != manifest["configuration_hash"]:
            raise ValueError("predecessor gate used different configurations")
    offline_gate = json.loads((DATA / "offline-gate.json").read_text())
    if offline_gate["protocol_hash"] != protocol_hash() or offline_gate["status"] != "passed":
        raise ValueError("offline gate stale")
    manifest_path = DATA / f"{batch}-manifest.json"
    if manifest_path.exists() and json.loads(manifest_path.read_text()) != manifest:
        raise ValueError("manifest changed: do not mix or overwrite experiments")
    write_json(manifest_path, manifest)
    archive_source()
    if not campaign_path.exists():
        with campaign_path.open("x") as file:
            json.dump(campaign, file, indent=2, sort_keys=True)
            file.write("\n")
    ledger = Ledger(RUNS / "spend.sqlite", cap=200, opening_balance=manifest["opening_balance"])
    snapshot = ledger.snapshot()
    if snapshot["unresolved_requests"] or snapshot["overruns"]:
        raise ValueError("accounting audit required before dispatch")
    load_env(ROOT / ".env")

    def run(job):
        output = RUNS / batch / f"{job['id']}.json"
        if output.exists():
            prior = json.loads(output.read_text())
            if prior["status"] != "complete":
                raise ValueError(
                    "unfinished attempt requires audit; never automatically redispatch"
                )
            return prior
        client = Client(Model(**manifest["models"][job["model"]]))
        return run_episode(
            generate(job["seed"], job["split"], job["size"]),
            client,
            episode_id=job["id"],
            stage=manifest["stage"],
            dollar_cap=job["dollar_cap"],
            token_cap=job["token_cap"],
            ledger=ledger,
            output=output,
        )

    # Bounded groups: inspect every member before dispatching the next. A failed request
    # retains liability and stops the batch; already dispatched peers still settle.
    with ThreadPoolExecutor(max_workers=workers) as pool:
        for start in range(0, len(manifest["jobs"]), workers):
            results = list(pool.map(run, manifest["jobs"][start : start + workers]))
            for ep in results:
                print(
                    json.dumps(
                        dict(
                            id=ep["id"],
                            status=ep["status"],
                            reason=ep["reason"],
                            quality=ep["quality"],
                            cost_usd=ep["cost_usd"],
                            actions=len(ep["actions"]),
                        )
                    ),
                    flush=True,
                )
            if any(ep["status"] != "complete" for ep in results):
                raise RuntimeError("batch stopped: review incomplete/quarantined attempts")
    print(json.dumps(dict(batch=batch, accounting=ledger.snapshot())), flush=True)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("command", choices=("offline", "plan", "run"))
    parser.add_argument("--batch", default="corrected_canary")
    parser.add_argument("--workers", type=int, choices=(1, 2, 3), default=1)
    args = parser.parse_args()
    DATA.mkdir(parents=True, exist_ok=True)
    if args.command == "offline":
        offline()
    elif args.command == "plan":
        print(json.dumps(plan(args.batch), indent=2))
    else:
        paid(args.batch, args.workers)


if __name__ == "__main__":
    main()
